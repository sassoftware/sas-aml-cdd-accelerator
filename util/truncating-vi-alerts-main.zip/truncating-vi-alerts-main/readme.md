# Removing Alerts from SAS Visual Investigator

This is a small project with a bash script for removing alerts
from SAS Visual Investigator. The script assumes the psql command
is on the user's PATH.

## Defining Your Target Environment

The shell script is environment variable driven. This allows you
to run them from any linux environment (or Cygwin on windows). I
typically create files under the env directory with connection
information for different servers and then just source the one I
need when I start working.

| Environment Variable | Description | Default Value|
|----------------------|-------------|:------------:|
| `SVI_DBHOST` | hostname for VI database | localhost |
| `SVI_DBPORT` | port (from command line) for VI database | 5432 |
| `SVI_DBNAME` | name of the VI database | VisualInvestigator |
| `SVI_PSQL_USER` | owner of the VI database | dbmsowner |
| `SVI_PSQL_PWD` | password for the VI database owner |  |

The database connection password can be passed in via environment
variable. If it is not, the script will prompt for that password.

<dl>

<dt>svi-env.sh</dt> 
<dd> 
This script displays all the environment variables that start with SVI. 
If you want to save the current environment variables to a file, 
you can invoke it with a filename, for example: <br/>
<br/>
<tt>% ./svi-env.sh env/pass1234</tt><br/>
<br/>
and it will write a file named <tt>pass1234</tt> in the <tt>env</tt>
directory. Then, in the future you can run <tt>source
env/pass1234</tt> to setup those variables again.
</dd>
</dl>

## Scripts

<dl>

<dt>remove-selected-alerts.sh</dt>
<dd>
Bash script to remove a set of alerts based on some chosen criteria.
The criteria is hard-coded into the sql in the script. The script then
removes all data related to the chosen alerts, including workspaces
and comments.
</dd>

<dt>remove-selected-alerts-by-id.sh</dt>
<dd>
Bash script to remove a set of alerts given a domain, the actionable entity
type and a list of actionable entity ids. The script completely removes those
alerts, including workspaces and comments.
</dd>

<dt>reset-alert-schema.sh</dt>
<dd>
Drops the alert schema and clears out a few bits in datahub so that
the alert service can rebuild the alert schema from scratch. You need
to stop the alert service before running this script.
</dd>

<dt>truncate-alerts.sh</dt>
<dd>Bash script to remove all the alerts in the system, 
along with their workspaces 
and comments via psql. Don't forget to reindex the alert entity afterwards.
</dd>

<dt>fast-truncate-alerts.sh</dt>
<dd>Bash script to remove all the alerts in the system, 
along with their workspaces and comments via psql
This is a new faster implementation that uses truncate instead of delete.
I will eventually fold it into the standard truncate-alerts.sh but I need
to find more time to test it. For now please consider it experimental and
let me know if it works for you. As always, 
don't forget to reindex the alert entity afterwards.
</dd>

<dt>truncate-alerts.sas</dt>
<dd>SAS script to remove all the alerts in the system, 
along with their workspaces 
and comments via a sas script. Don't forget to reindex the alert entity
afterwards.
</dd>

</dl>
