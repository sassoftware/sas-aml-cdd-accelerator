#!/bin/bash

#
# shell script to delete existing alerts and related objects
#
PSQL=psql

DBHOST=${SVI_DBHOST:-localhost}
DBPORT=${SVI_DBPORT:-5432}
DATABASE_NM=${SVI_DBNAME:-VisualInvestigator}

DBOWNER=${SVI_PSQL_USER:-dbmsowner}

# psql looks for a password in an environment variable named PGPASSWORD.

if [[ -z ${SVI_PSQL_PWD} ]] ; then
  read -s -p "Password for ${DBOWNER}: " PGPASSWORD
  echo
else
  PGPASSWORD=${SVI_PSQL_PWD}
fi

export PGPASSWORD

d=$(dirname $0)
source $d/bin/functions.sh
initializeDatabaseAccess

computeViVersion

echo Truncating scenario admin event history VI ${VI_VERSION} postgresql://${DBHOST}:${DBPORT}/${DATABASE_NM}

read -p "Press [enter] to continue " go
if [[ "$go" == 'n'* ]] ; then 
  exit
fi

${PSQL} -h ${DBHOST} -p ${DBPORT} -U ${DBOWNER} ${DATABASE_NM} <<EOF
$ENABLE_FOR_10_7 truncate svi_vsd_service.vsd_event_history;

EOF
