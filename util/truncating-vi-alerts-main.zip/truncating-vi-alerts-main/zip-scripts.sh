#!/bin/bash
zip ../truncate-vi-alerts.zip readme.* truncate-alerts.* svi-env.sh env/acme.localhost 


