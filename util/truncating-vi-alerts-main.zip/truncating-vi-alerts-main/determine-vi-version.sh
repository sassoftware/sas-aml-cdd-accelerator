#!/bin/bash

#
# Usage: determine-vi-version.sh <psql-timestamp>
#
# Emit the vi version number as a string
#

d=$(dirname $0)
. $d/bin/functions.sh

initializeDatabaseAccess

computeViVersion

echo $VI_VERSION
