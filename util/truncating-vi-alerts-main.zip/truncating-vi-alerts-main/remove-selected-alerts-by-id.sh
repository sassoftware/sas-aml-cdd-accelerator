#!/bin/bash

#
# shell script to delete a list of existing alerts and alerting events, etc.
# from a list of arguments passed in on the command line. The complete list
# of arguments is the domain id, the actionable entity type name and then
# a list of ids.
#

if [ -z "$3" ] ; then
    echo usage $0 domain_id entity_type_nm entity_type_id \[ entity_type_id \]
    exit
fi

PSQL=psql

DBHOST=${SVI_DBHOST:-localhost}
DBPORT=${SVI_DBPORT:-5432}
DATABASE_NM=${SVI_DBNAME:-VisualInvestigator}
DBOWNER=${SVI_PSQL_USER:-dbmsowner}

# psql looks for a password in an environment variable named PGPASSWORD.

if [[ -z ${SVI_PSQL_PWD} ]] ; then
  read -s -p "Password for ${DBOWNER}: " PGPASSWORD
  echo
else
  PGPASSWORD=${SVI_PSQL_PWD}
fi

export PGPASSWORD

d=$(dirname $0)
source $d/bin/functions.sh
initializeDatabaseAccess

computeViVersion

#
# assemble where clause
#

function build_id_list {
    prefix=''
    separator=','
    for id in $*; do
        echo -n "${prefix}'${id}'"
	prefix=${separator}
    done
    echo
}

#
# assemble where clause
#
DOMAIN_ID=$1
ENTITY_TYPE_NM=$2
shift
shift

WHERE_CLAUSE="where "
WHERE_CLAUSE="${WHERE_CLAUSE} domain_id = '${DOMAIN_ID}' "
WHERE_CLAUSE="${WHERE_CLAUSE} and actionable_entity_type_nm = '${ENTITY_TYPE_NM}'"
WHERE_CLAUSE="${WHERE_CLAUSE} and actionable_entity_id in ($(build_id_list $*))"

echo Truncating scores and alerts from VI ${VI_VERSION} postgresql://${DBHOST}:${DBPORT}/${DATABASE_NM} ${WHERE_CLAUSE}
echo Truncating alerts and alerting events from postgresql://${DBHOST}:${DBPORT}/${DATABASE_NM}

read -p "This script will delete the complete history of those alerts. Press [y/n] to continue " go
if [[ "$go" != 'y'* ]] ; then 
  exit
fi

${PSQL} -h ${DBHOST} -p ${DBPORT} -U ${DBOWNER} ${DATABASE_NM} <<EOF

drop table svi_alerts.alerts_tbd;
drop table svi_alerts.alerting_events_tbd;
drop table svi_alerts.sfe_tbd;
$ENABLE_FOR_10_8 drop table svi_alerts.scores_tbd;

--
-- identify the list of alerts to destroy
-- this is the query you may want to edit
--
create table svi_alerts.alerts_tbd as
select alert_id from svi_alerts.tdc_alert ${WHERE_CLAUSE};

create index alerts_tbd_idx on svi_alerts.alerts_tbd using hash(alert_id);

--
-- now make lists of the impacted AE and SFE
--

create table svi_alerts.alerting_events_tbd as
select alerting_event_id from svi_alerts.tdc_alerting_event where alert_id in (select alert_id from svi_alerts.alerts_tbd);

create index alerting_events_tbd_idx on svi_alerts.alerting_events_tbd using hash(alerting_event_id);

create table svi_alerts.sfe_tbd as
select scenario_fired_event_id from svi_alerts.tdc_scenario_fired_event where alerting_event_id in (select alerting_event_id from svi_alerts.alerting_events_tbd);

create index sfe_tbd_idx on svi_alerts.sfe_tbd using hash(scenario_fired_event_id);

$ENABLE_FOR_10_8 create table svi_alerts.scores_tbd as
$ENABLE_FOR_10_8 select score_id from svi_alerts.tdc_score where alerting_event_id in (select alerting_event_id from svi_alerts.alerting_events_tbd);

$ENABLE_FOR_10_8 create index scores_tbd_idx on svi_alerts.scores_tbd using hash(score_id);

--
-- what did we find?
--

select count(*) as num_alerts_to_delete from svi_alerts.alerts_tbd;
select count(*) as num_ae_to_delete from svi_alerts.alerting_events_tbd;
select count(*) as num_sfe_to_delete from svi_alerts.sfe_tbd;

$ENABLE_FOR_10_8 select count(*) as num_scores_to_delete from svi_alerts.scores_tbd;

select count(*) as existing_alerts from svi_alerts.tdc_alert;
select count(*) as existing_alert_history_records from svi_alerts.tdc_alert_action;
select count(*) as existing_sfe_records from svi_alerts.tdc_scenario_fired_event;
$ENABLE_FOR_10_8 select count(*) as existing_scores from svi_alerts.tdc_score;
select count(*) as existing_co_records from svi_alerts.tdc_contributing_object;
select count(*) as existing_ro_records from svi_alerts.tdc_replicated_object;

delete from svi_alerts.tdc_replicated_object where scenario_fired_event_id in (select scenario_fired_event_id from svi_alerts.sfe_tbd);
delete from svi_alerts.tdc_contributing_object where alerting_event_id in (select alerting_event_id from svi_alerts.alerting_events_tbd);
$ENABLE_FOR_10_7 delete from svi_alerts.tdc_suppressed_scenario where alert_id in (select alert_id from svi_alerts.alerts_tbd);
$ENABLE_FOR_10_7 delete from svi_alerts.tdc_scenario_fired_event_suppression where sfe_id in (select scenario_fired_event_id from svi_alerts.sfe_tbd);
$ENABLE_FOR_10_6 delete from svi_alerts.tdc_scenario_fired_event_disposition where sfe_id in (select scenario_fired_event_id from svi_alerts.sfe_tbd);
delete from svi_alerts.tdc_scenario_fired_event where scenario_fired_event_id in (select scenario_fired_event_id from svi_alerts.sfe_tbd);

update svi_alerts.tdc_alerting_event set alert_id = null where alerting_event_id in (select alerting_event_id from svi_alerts.alerting_events_tbd);
$ENABLE_FOR_10_8 update svi_alerts.tdc_alerting_event set score_id = null where alerting_event_id in (select alerting_event_id from svi_alerts.alerting_events_tbd);

delete from svi_alerts.tdc_alert where alert_id in (select alert_id from svi_alerts.alerts_tbd);
delete from svi_alerts.tdc_alert_action where alert_id in (select alert_id from svi_alerts.alerts_tbd);
$ENABLE_FOR_10_8 delete from svi_alerts.tdc_score where score_id in (select score_id from svi_alerts.scores_tbd);
delete from svi_alerts.tdc_alerting_event where alerting_event_id in (select alerting_event_id from svi_alerts.alerting_events_tbd);

$ENABLE_FOR_10_7 delete from svi_vsd_service.vsd_event_history where vsd_scenario_fired_event_id in (select scenario_fired_event_id from svi_alerts.sfe_tbd);


--
-- how does it look now?
--

select count(*) as existing_alerts from svi_alerts.tdc_alert;
select count(*) as existing_alert_history_records from svi_alerts.tdc_alert_action;
select count(*) as existing_sfe_records from svi_alerts.tdc_scenario_fired_event;
$ENABLE_FOR_10_8 select count(*) as existing_score_records from svi_alerts.tdc_score;
select count(*) as existing_co_records from svi_alerts.tdc_contributing_object;
select count(*) as existing_ro_records from svi_alerts.tdc_replicated_object;


--
-- cleanup datahub stuff
--
select count(*) as workspaces_to_delete from fdhdata.dh_document_sheet 
    where document_type_nm = 'alerts' and document_id in (select alert_id from svi_alerts.alerts_tbd);

create table fdhdata.temp_workspaces_tbd as
select document_sheet_id from fdhdata.dh_document_sheet
where document_type_nm = 'alerts' and document_id in (select alert_id from svi_alerts.alerts_tbd);

delete from fdhdata.dh_document_reference_cell where document_sheet_cell_id in 
 (select document_sheet_cell_id from fdhdata.dh_document_sheet_cell where document_sheet_id in
   (select document_sheet_id from fdhdata.temp_workspaces_tbd));

delete from fdhdata.dh_entity_reference_cell where document_sheet_cell_id in 
 (select document_sheet_cell_id from fdhdata.dh_document_sheet_cell where document_sheet_id in
   (select document_sheet_id from fdhdata.temp_workspaces_tbd));

delete from fdhdata.dh_document_sheet_cell where document_sheet_id in (select document_sheet_id from fdhdata.temp_workspaces_tbd);

delete from fdhdata.dh_document_sheet where document_sheet_id in (select document_sheet_id from fdhdata.temp_workspaces_tbd);

drop table fdhdata.temp_workspaces_tbd;

delete from fdhdata.dh_comment where parent_type_nm = 'alerts' and parent_id in (select alert_id from svi_alerts.alerts_tbd);

--
-- remove temp tables
--
drop table svi_alerts.alerts_tbd;
drop table svi_alerts.alerting_events_tbd;
drop table svi_alerts.sfe_tbd;
$ENABLE_FOR_10_8 drop table svi_alerts.scores_tbd;

EOF

#
# if you are removing a lot of alerts you probably want to vacuum the tables
#

${PSQL} -h ${DBHOST} -p ${DBPORT} -U ${DBOWNER} ${DATABASE_NM} <<EOF

-- one alert probably not worth vacuuming

--$ENABLE_FOR_10_8 vacuum svi_alerts.tdc_score;
--$ENABLE_FOR_10_7 vacuum svi_alerts.tdc_suppressed_scenario;
--$ENABLE_FOR_10_7 vacuum svi_alerts.tdc_scenario_fired_event_suppression;
--$ENABLE_FOR_10_6 vacuum svi_alerts.tdc_scenario_fired_event_disposition;
--vacuum svi_alerts.tdc_scenario_fired_event;
--vacuum svi_alerts.tdc_alerting_event;
--vacuum svi_alerts.tdc_alert;
--vacuum svi_alerts.tdc_alert_action;
--vacuum svi_alerts.tdc_contributing_object;
--vacuum svi_alerts.tdc_replicated_object;

EOF

echo Don\'t forget to reindex the alert entity. 
