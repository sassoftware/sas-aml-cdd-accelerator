#!/bin/bash

#
# shell script to reset the alert schema back to its pristine condition
#
PSQL=psql

DBHOST=${SVI_DBHOST:-localhost}
DBPORT=${SVI_DBPORT:-5432}
DATABASE_NM=${SVI_DBNAME:-VisualInvestigator}

DBOWNER=${SVI_PSQL_USER:-dbmsowner}

# psql looks for a password in an environment variable named PGPASSWORD.

if [[ -z ${SVI_PSQL_PWD} ]] ; then
  read -s -p "Password for ${DBOWNER}: " PGPASSWORD
  echo
else
  PGPASSWORD=${SVI_PSQL_PWD}
fi

export PGPASSWORD

d=$(dirname $0)
source $d/bin/functions.sh
initializeDatabaseAccess

computeViVersion

echo Resetting the alert schema in postgresql://${DBHOST}:${DBPORT}/${DATABASE_NM}
echo You must stop the svialert service before continuing.
read -p "Press [enter] to continue " go
if [[ "$go" == 'n'* ]] ; then 
  exit
fi

${PSQL} -h ${DBHOST} -p ${DBPORT} -U ${DBOWNER} ${DATABASE_NM} <<EOF

drop schema svi_alerts cascade;

delete from fdhmetadata.dh_reference_table_item
where list_id in (
   select list_id from fdhmetadata.dh_reference_table
   where created_by_user_id = 'sas.svi-alert');

delete from fdhmetadata.dh_reference_table
where created_by_user_id = 'sas.svi-alert';

EOF

echo You can restart the alert service now.

echo Don\'t forget to reindex the alert entity. 
