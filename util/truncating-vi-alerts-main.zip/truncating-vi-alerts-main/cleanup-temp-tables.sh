#!/bin/bash

#
# shell script to delete a list of existing alerts and related objects
#
PSQL=psql

DBHOST=${SVI_DBHOST:-localhost}
DBPORT=${SVI_DBPORT:-5432}
DATABASE_NM=${SVI_DBNAME:-VisualInvestigator}

DBOWNER=${SVI_PSQL_USER:-dbmsowner}

# psql looks for a password in an environment variable named PGPASSWORD.

if [[ -z ${SVI_PSQL_PWD} ]] ; then
  read -s -p "Password for ${DBOWNER}: " PGPASSWORD
  echo
else
  PGPASSWORD=${SVI_PSQL_PWD}
fi

export PGPASSWORD

echo truncating scores and alerts from postgresql://${DBHOST}:${DBPORT}/${DATABASE_NM}

read -p "This script will delete the complete history of the selected alerts. Press [y/n] to continue " go
if [[ "$go" != 'y'* ]] ; then 
  exit
fi

${PSQL} -h ${DBHOST} -p ${DBPORT} -U ${DBOWNER} ${DATABASE_NM} <<EOF

--
-- remove temp tables
--
drop table svi_alerts.alerts_tbd;
drop table svi_alerts.alerting_events_tbd;
drop table svi_alerts.sfe_tbd;

EOF
