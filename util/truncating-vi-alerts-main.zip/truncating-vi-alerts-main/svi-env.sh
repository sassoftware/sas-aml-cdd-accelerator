#/bin/bash

#
# with no args, show all SVI environment variables.
# with 1-arg, write all SVI environment variables to a file.
#

echo Current environment
echo
env | grep SVI | sort

if [ -n "$1" ]; then
  FN=$1
  echo "Save current environment as $FN?"
  read -p "Press [enter] to continue " yes
  if [[ "$yes" == 'n'* ]] ; then
    echo "skipping ..."
  else
    rm --force env/$FN
    for i in `env | grep SVI | sort` ; do
      echo export $i \>\> env/$FN
      echo export $i >> env/$FN
    done
  fi
fi

